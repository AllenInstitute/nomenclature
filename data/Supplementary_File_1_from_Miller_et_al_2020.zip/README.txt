This zip file contains output files created after running the CCN on 17 taxonomies.  There are three sets of files:

cell_set_nomenclature.xlsx - This file includes the annotated cell sets from all 17 taxonomies and is divided into three sheets.

* taxonomy ids = the set of taxonomy IDs along with some meta-data about how the cell set annotations were generated (manually or using the GitHub code) and about which additional output files are included in this zip file.  This table is the same as Table 4, but with additional columns.

* aligned aliases = this is the set of aligned aliases used for all taxonomies herein.  This is a reproduction of Supplementary File 2.

* cell set nomenclature = this is the sheet with the annotated cell sets, which includes all of the tags described in the manuscript and on the GitHub repo (https://github.com/AllenInstitute/nomenclature), along with tags for species and modality.

dendrogram_[taxonomy_id].[json/RData] - dendrograms annotated with all of the CCN tags and any additional meta-data tags included when running the script for [taxonomy_id].  If provided, these taxonomies are provided in both json and RData format.

cell_to_cell_set_assignments_[taxonomy_id].csv - a table of binary calls (0=no, 1=yes) indicating exclusion or inclusion of each cell in each cell set 

NOTE: For future cell typing studies, these three output files are intended to be directly included as supplemental materials in manuscripts performing cell type classification (in any organ system or species).